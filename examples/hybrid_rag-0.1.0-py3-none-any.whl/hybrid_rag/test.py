# from api import advance_rag_chatbot
# {query": "tell me about cuda setup?",
# history = [
#     ["hi", "hey how can i assist you today"],
#     ["what is cuda", "cuda is an Nvidia package to code on GPUs"]
#   ]
# }
